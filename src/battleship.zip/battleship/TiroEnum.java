/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package battleship;

/**
 *
 * @author elder
 */
public enum TiroEnum {
    DESCOBERTA, AGUA, FOGO, AFUNDAR
}
